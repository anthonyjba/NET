﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestCodility
{
    class Program
    {
        static void Main(string[] args)
        {
            
            string input = "00:01:07,400-234-090\n00:05:01,701-080-080\n00:05:00,400-234-090";
            int result = solution(input);
            
            Console.WriteLine(result);
            Console.ReadLine();
        }

        public static int solution(string S)
        {
            var time = String.Empty;
            var phone = String.Empty;
            double paybycall = 0;

            string[] lines = S.Split('\n');

            if (lines.Length < 1 || lines.Length > 100)
                return -1;

            Dictionary<string, object> phones = new Dictionary<string, object>();

            foreach (string current in lines)
            {
                var call = current.Split(',');
                time = call[0]; phone = call[1];
                double seconds = TimeSpan.Parse(time).TotalSeconds;
                paybycall = seconds < 300 ? seconds * 3 : Math.Ceiling(seconds / 60) * 150;

                
                if (!phones.ContainsKey(call[1]))
                    phones.Add(call[1], new callphone() { duration = seconds, bill = paybycall });
                else
                {
                    callphone o = (callphone)phones[call[1]];
                    o.duration += seconds;
                    o.bill += paybycall;
                }
            }

            //To remove free Call 
            var max = phones.Max(x => ((callphone)x.Value).duration);
            var removeFreeCall = phones.Where(kvp => ((callphone)kvp.Value).duration == max).Select(kvp => kvp.Key).First();
            phones.Remove(removeFreeCall);

            //To get de longest 
            max = phones.Max(x => ((callphone)x.Value).duration);
            var longestCall = phones.Where(kvp => ((callphone)kvp.Value).duration == max).Select(kvp => kvp.Value).First();

            return Convert.ToInt32(((callphone)longestCall).bill);


        }
        class callphone {
            public double duration { get; set; }
            public double bill { get; set;  }
        }

        
    }
}
